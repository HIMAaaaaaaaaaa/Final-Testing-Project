from flask import Flask, request, render_template, redirect, url_for # type: ignore
import sqlite3
import os.path

app = Flask(__name__)

# Define the path to your SQLite database (relative path is recommended)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, 'TestDB.db')  # Using os.path.join for platform independence

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    else:
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cur = conn.cursor()

        # Check if the username already exists
        cur.execute('SELECT * FROM users WHERE username = ?', (username,))
        if cur.fetchone():
            conn.close()
            return "Username already exists. Please choose a different username."

        # Insert new user (consider using prepared statements to prevent SQL injection)
        cur.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()

        return redirect(url_for('success'))

@app.route('/success')
def success():
    return render_template('success.html')

if __name__ == "__main__":
    app.run(debug=True)
