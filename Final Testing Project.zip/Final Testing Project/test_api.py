import time
from typing import Self
import unittest
import sqlite3
import os.path

import requests

from app import app  # type: ignore

class LibraryAPITestCase(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        app.config['TESTING'] = True
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        app.config['DATABASE'] = os.path.join(BASE_DIR, 'library_test.db')
        with app.app_context():
            conn = sqlite3.connect(app.config['DATABASE'], uri=True)
            conn.execute('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, author TEXT NOT NULL, isbn TEXT NOT NULL)')
            conn.commit()

    def test_add_book(self):
        response = self.app.post('/books', json={'title': 'New Book', 'author': 'Author Name', 'hima': '9517532460'})
        self.assertEqual(response.status_code, 201)

    def test_get_book(self):
        # Add a book first
        add_book(self.app, 'Existing Book', 'Existing Author', '123456')
        # Now retrieve the book with authorization
        response = get_book(self.app, 1, headers={'Authorization': 'ValidToken'})
        self.assertEqual(response.status_code, 200)
        # Additional assertions to check the response content

    def test_update_nonexistent_book(self):
        response = self.app.put('/books/999', json={'title': 'Updated Book', 'author': 'Author Name', 'hima': '9517532460'})
        self.assertEqual(response.status_code, 404)

    def test_delete_nonexistent_book(self):
        response = self.app.delete('/books/999')
        self.assertEqual(response.status_code, 404)

    def test_get_book_unauthorized(self):
        response = get_book(self.app, 1, headers={'Authorization': 'InvalidToken'})
        self.assertEqual(response.status_code, 401)

    def test_book_data_integrity(self):
        response = self.app.post('/books', json={'title': 'Integrity Check', 'author': 'Author', 'hima': '9517532460'})
        self.assertEqual(response.status_code, 201)
        response_data = response.get_json()
        self.assertIn('id', response_data)

    def test_response_time(self):
  """Tests the response time of the API endpoint."""
  start_time = time.time()
  response = requests.get('http://localhost:4950/books')  # Assuming the endpoint is '/books'
  end_time = time.time()

  Self.assertTrue(end_time - start_time < 0.3, "The response time exceeded the expected threshold.")

if __name__ == '__main__':
  unittest.main()