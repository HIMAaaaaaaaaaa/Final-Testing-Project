from flask import Flask, request, jsonify # type: ignore
import sqlite3


app = Flask(__name__)


def get_db_connection():
    conn = sqlite3.connect('library.db')
    conn.row_factory = sqlite3.Row
    return conn


def initialize_db():
    conn = get_db_connection()
    conn.execute('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, author TEXT NOT NULL, isbn TEXT NOT NULL)')
    conn.commit()
    conn.close()


@app.route('/books', methods=['GET', 'POST'])
def books():
    if request.method == 'GET':
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM books')
        all_books = cursor.fetchall()
        conn.close()
        return jsonify([dict(book) for book in all_books]), 200
    else:  # POST
        return add_book()


@app.route('/books/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def book(id):
    # Simulated authorization check (consider a more robust mechanism)
    auth_token = request.headers.get('Authorization')
    if not auth_token or auth_token != "ValidToken":
        return jsonify({"error": "Unauthorized"}), 401

    if request.method == 'GET':
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM books WHERE id = ?', (id,))
        book = cursor.fetchone()
        conn.close()

        if book is None:
            return jsonify({"error": "Book not found"}), 404

        return jsonify(dict(book)), 200
    elif request.method == 'PUT':
        return update_book(id)
    elif request.method == 'DELETE':
        return delete_book(id)
    else:
        return jsonify({"error": "Unsupported method"}), 405


def add_book():
    try:
        # Validate request data (title, author, ISBN)
        if not request.is_json or 'title' not in request.json or 'author' not in request.json or 'isbn' not in request.json:
            return jsonify({"error": "Invalid request data"}), 400

        book_details = request.json
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)',
                       (book_details['title'], book_details['author'], book_details['isbn']))
        book_id = cursor.lastrowid
        conn.commit()
        conn.close()

        book_details['id'] = book_id
        return jsonify(book_details), 201
    except sqlite3.Error as e:
        return jsonify({"error": f"Database error: {str(e)}"}), 500


def update_book(id):
    try:
        # Validate request data
        if not request.is_json or 'title' not in request.json or 'author' not in request.json or 'isbn' not in request.json:
            return jsonify({"error": "Invalid request data"}), 400

        book_details = request.json
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if the book exists
        cursor.execute('SELECT * FROM books WHERE id = ?', (id,))
        book = cursor.fetchone()
        if book is None:
            return jsonify({"error": "Book not found"}), 404

        # Update the book if it exists
        cursor.execute('UPDATE books SET title = ?, author = ?, isbn = ? WHERE id = ?',
                       (book_details['title'], book_details['author'], book_details['isbn'], id))
        conn.commit()
        conn.close()

        book_details['id'] = id
        return jsonify(book_details), 200
    except sqlite3.Error as e:
        return jsonify({"error": f"Database error: {str(e)}"}), 500


def delete_book(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if the


@app.route('/books/<int:id>', methods=['DELETE'])
def delete_book(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if the book exists
    cursor.execute('SELECT * FROM books WHERE id = ?', (id,))
    book = cursor.fetchone()
    if not book:
        conn.close()
        return {"error": "Book not found"}, 404

    # If the book exists, proceed with deletion
    cursor.execute('DELETE FROM books WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return '', 204

if __name__ == '__main__':
    initialize_db()  # Ensure the database and table are created
    app.run(debug=True)