from locust import HttpUser, task, between # type: ignore

class WebsiteUser(HttpUser):
    wait_time = between(1, 3)  # Wait between 1 and 3 seconds between tasks

    @task
    def register_user(self):
        """Registers a new user on the website."""
        # Define the data for the POST request
        user_data = {
            "username": "testuser",
            "password": "password",
        }
        # Send a POST request to the /register endpoint
        self.client.post("/register", json=user_data)
