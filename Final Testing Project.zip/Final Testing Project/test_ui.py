import pytest # type: ignore
from selenium import webdriver # type: ignore
from selenium.webdriver.common.by import By # type: ignore
from selenium.webdriver.support.ui import WebDriverWait # type: ignore
from selenium.webdriver.support import expected_conditions as EC # type: ignore


@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.implicitly_wait(10)
    yield driver
    driver.quit()


def test_data():
    return {
        "username_valid": "hima24",
        "password": "StrongPassword",
        "username_existing": "himahima10",  # Existing username (from previous test)
        "error_message": "Username already exists"
    }


def enter_text(driver, locator, text):
    element = driver.find_element(locator)
    element.send_keys(text)


def test_successful_registration(driver, test_data):
    driver.get("http://localhost:4950/register")
    enter_text(driver, By.NAME, test_data["username_valid"])
    enter_text(driver, By.NAME, test_data["password"])
    driver.find_element(By.XPATH, "//button").click()
    WebDriverWait(driver, 10).until(EC.url_to_be("http://localhost:4950/success"))
    assert "Well done!" in driver.page_source


def test_failed_registration_existing_user(driver, test_data):
    driver.get("http://localhost:4950/register")
    enter_text(driver, By.NAME, test_data["username_existing"])
    enter_text(driver, By.NAME, test_data["password"])
    driver.find_element(By.XPATH, "//button").click()
    assert test_data["error_message"] in driver.page_source
    assert driver.current_url == "http://localhost:4950/register"
